<?php

$url = $_SERVER['REQUEST_URI'];

// echo $url;

// if ($url == '/thakur/thajurvilla/') {
//     include 'login/userlogin.php';
// }

// include 'login/userlogin.php';

if ($url == '/HotelManagement/') {
    include 'login/userlogin.php';
}

?>