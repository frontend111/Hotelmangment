<?php

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not
    header('Location: /HotelManagement/login/login.php');
    exit();
}

// Check if a URL parameter named "ordeid" is set
if (isset($_GET['orderid'])) {
    // Get the value of the "ordeid" parameter
    $page = $_GET['orderid'];

    $form_var = $_GET['formsubmission'];

    // Connect to the MySQL database using mysqli
    $conn = mysqli_connect('localhost', 'root', '', 'mydatabase');

    // Check if the connection was successful
    if (!$conn) {
        die('Failed to connect to MySQL: ' . mysqli_connect_error());
    }

    // Check if the "orders" table exists
    $table_check_query = "SHOW TABLES LIKE 'orders'";
    $result = mysqli_query($conn, $table_check_query);

    if (mysqli_num_rows($result) == 0) {
        // If the table doesn't exist, create it
        $create_table_query = "CREATE TABLE orders (
            id INT(11) NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            order_id VARCHAR(255) NOT NULL,
            table_number VARCHAR(255) NOT NULL,
            username VARCHAR(255) NOT NULL,
            address VARCHAR(255) NOT NULL,
            PRIMARY KEY (id)
        )";

        if (!mysqli_query($conn, $create_table_query)) {
            die('Failed to create orders table: ' . mysqli_error($conn));
        }
    }

    // Check if the form was submitted
    if (isset($_POST['submit'])) {
        // Get the values from the form
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        // $order_id = $_POST['order_id'];
        $username = $_SESSION['username'];
        $address = $_POST['address'];

        // Search for a free entry
        $search_sql = "SELECT * FROM hotel_tables WHERE availability='free' LIMIT 1";
        $search_result = mysqli_query($conn, $search_sql);

        if (mysqli_num_rows($search_result) > 0) {
            // Free entry found, retrieve the ID
            $row = mysqli_fetch_assoc($search_result);

            print_r($row);

            $table_id = $row['table_number'];

            echo $table_id;
            
            // Insert the values into the "orders" table
            $insert_query = "INSERT INTO orders (name, email, phone, order_id, username, address, table_number)
                VALUES ('$name', '$email', '$phone', '$page', '$username', '$address', '$table_id')";

            if (!mysqli_query($conn, $insert_query)) {
                die('Failed to save order: ' . mysqli_error($conn));
            }

        } else {
        // No free entry found
        echo "No free tables found.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Form</title>
    <link rel="stylesheet" href="/HotelManagement/oredr.css">
</head>
<body>
    <div class="container">
    <h1>Order Form</h1>
    <form method="post" action="order.php?orderid=<?php echo $page; ?>&formsubmission=form">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>

        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" required><br><br>

        <label for="order_id">Order ID:</label>
        <input disabled value = "<?php echo $page; ?>" type="text" name="order_id" required><br><br>

        <label for="username">Username:</label>
        <input disabled type="text" name="username" value = "<?php echo $_SESSION['username']; ?>" required><br><br>

        <label for="address">Address:</label>
        <input type="text" name="address" required><br><br>

        <!-- <button type="submit" name="submit">Submit Order</button> -->
        <input type="submit" name="submit">

    </form>
    </div>

    <?php
    // Check if the page parameter is set to "form"
    if ($form_var === 'form') {
        echo "<h2>Order details saved!</h2>";
        header('location: /HotelManagement/home.php');
    }
    ?>

</body>
</html>
