<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" href="/HotelManagement/registration/r.css">
</head>

<body>
	<div class="container">
	<h1>Register</h1>
	<form method="POST" action="/HotelManagement/registration/register.php">
		<label for="username">Username:</label>
		<input type="text" name="username" required><br><br>
		<label for="password">Password:</label>
		<input type="password" name="password" required><br><br>
		<label for="confirm_password">Confirm Password:</label>
		<input type="password" name="confirm_password" required><br><br>
		<input type="submit" value="Register">
	</form>
	</div>
</body>
</html>
