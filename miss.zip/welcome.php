<?php

//echo" Succefully order";
$servername = "localhost";
$username = "root";
$password = "";
$database = "resturent";

print_r($_POST);



$firstname =$_POST['firstname'];
$email=$_POST['email'];
$password1=$_POST['password'];
$number=$_POST['number'];
$order=$_POST['order'];


$con=new mysqli($servername,$username,$password,$database);//database name resturent
if ($con->connect_error)
    {
        die("Failed connection :".$con->connect_error);
    }
    else{
        //table nmae villa
        $sql = "INSERT INTO  villa(`firstname`,`email`,`password`,`number`,`order`)
        VALUES('$firstname','$email','$password1','$number','$order')";
         echo "your email",$email;
         if($con->query($sql)==TRUE){
            echo"Your order succefully genrated";
         }else{

            echo "Error: ".$sql."<br>". $con->error;
         }
       $con->close();
    }
?>