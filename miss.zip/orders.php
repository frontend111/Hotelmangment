<?php
// Get the username parameter
$username = $_GET['username'];

$conn = mysqli_connect('localhost', 'root', '', 'mydatabase');

// Search for entries with matching username
$sql = "SELECT * FROM orders WHERE username='$username'";

$result = mysqli_query($conn, $sql);

// Generate HTML table to display results
if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>ID</th><th>NAME</th><th>EMAIL</th><th>PHONE</th><th>ORDER ID</th><th>TABLE NUMBER</th><th>USERNAME</th><th>ADDRESS</th></tr>";
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "<td>" . $row['phone'] . "</td>";
    echo "<td>" . $row['order_id'] . "</td>";
    echo "<td>" . $row['table_number'] . "</td>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['address'] . "</td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  // No entries found
  echo "No tables found for user: " . $username;
}

// Close the database connection
mysqli_close($conn);
?>
