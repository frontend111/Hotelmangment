<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {

    // Redirect to the login page if not
    header('Location: /HotelManagement/login/login.php');
    exit();
}
?>

<html>
    <head>
        <title>THAKURVILLA</title>
        <link rel="stylesheet" href="style.css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>

        <style>
            form {
                margin: 0 !important;
            }

            .logout_btn {
                margin: 0 !important;
                padding: 0 !important;
            }
        </style>
    </head>
    <body>
        <nav>
            <!-- https://www.youtube.com/watch?v=nKnrdABs7Zs -->
            <div class="logo"> THAKURVILLA</div>
            <input type="checkbox" id="click">
            <label for="click" class="menu-btn">
                <i class="fas fa-bars"></i>
            </label>
                <ul>
                    <li><a class="active" href="#">Home</a></li>
                    <!-- <li><a href="#">Service</a></li> -->
                    <li><a href="menucard.html">Menu</a></li>
                   
                    <li><a href="/HotelManagement/orders.php?username=<?php echo $_SESSION['username']; ?>" >Orders</a></li>
                    <li>
                        <a><?php
                            // Display the username
                            echo 'Logged in as: ' . $_SESSION['username'] . '';
                            ?>
                        </a>
                    </li>

                    <li>
                    <form action="/HotelManagement/logout.php" method="post">
                        <button class = "logout_btn" type="submit" name="logout">Logout</button>
                    </form>
                    </li>
                </ul>
           
        </nav>
        <div class="text">
            <h4> EAT . ENERGY . BULDER</h4>
            <h1>TASTY FOOD BRINGS ETERNAL BLISS.</h1>
            <h3>Food is essential to life because it provides the energy to run body</h3>
            <button id="buttonone">Daily Offer</button>
        </div>

    </div>
</header>
<!-- Image gallary -->
<section>
    <h2>Menu</h2>
    <div class="contaner">
        <div class="card">
            <div class="card-image car1">
            </div>
            <h2>Chacolate Cold</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.1</div>
            <button><a href="/HotelManagement/order.php?orderid=chocolatecold&formsubmission=0">ORDER</a></button>
        </div>
        <div class="card">
            <div class="card-image car5"></div>

            <h2>Butter Pizza</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.2</div>
            <button><a href="/HotelManagement/order.php?orderid=butterpizza&formsubmission=0">ORDER</a></button>
        </div>
        <div class="card">
            <div class="card-image car3"> </div>
            <h2>Chickan Burger</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.3</div>
            <button><a href="/HotelManagement/order.php?orderid=chickenburger&formsubmission=0">ORDER</a></button>
        </div>
        <div class="card">
            <div class="card-image car2"> </div>
            <h2>Pizza</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID <no class="4"></no>
            </div>
            <button><a href="/HotelManagement/order.php?orderid=pizza&formsubmission=0">ORDER</a></button>
        </div>

        <div class="card">
            <div class="card-image car4"> </div>
            <h2>Fried red chickan</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.5</div>
            <button><a href="/HotelManagement/order.php?orderid=friedredchicken&formsubmission=0">ORDER</a></button>
        </div>
        <div class="card">
            <div class="card-image car5"> </div>
            <h2>Fish fried</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.6</div>
            <button><a href="/HotelManagement/order.php?orderid=fishfried&formsubmission=0">ORDER</a></button>
        </div>
        <div class="card">
            <div class="card-image car2"> </div>
            <h2>Non-veg pizaa</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.7</div>
            <button><a href="/HotelManagement/order.php?orderid=nonvegpizza&formsubmission=0">ORDER</a></button>
        </div>
        <div class="card">
            <div class="card-image car6"> </div>
            <h2>Chickan Biriyani</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Exercitationem assumenda vel, quae tempora ex, explicabo dignissimos maiores autem, </p>
            <div class="id">ID no.8</div>
            <button><a href="/HotelManagement/order.php?orderid=chickenbiryani&formsubmission=0">ORDER</a></button>
        </div>
    </div>

</section>

<!-- Login form -->
<div id="container">
    <!-- <h2>ORDER</h2> -->
    <div class="section1">
        
        <article>
            
            <div class="inner">
                <h1>Welcome</h1>
                <p>TO VISIT MY RESTURENT</p>
                <p>To keep connected with us please login</p>
                <a href="" class="btn">Login</a>
            </div>
        </article>
        <aside>
            <div class="inner">
                <h2>ORD<span>ER</span> HERE</h2>
                
                    <p>Use your email for order</p>
                    <form action="welcome.php" method="Post">
                        <input type="text" placeholder="Fullname" name="firstname" id="firstname">
                        <input type="email" placeholder="E-mail" name="email" id="email">
                        <input type="password" placeholder="Password" name="password" id="password">
                        <input type="phonenumber" placeholder="+91" name="number" id="number">
                        <input type="text" placeholder="Oredr Id No.1" name="order" id="order">
                        <input type="text" placeholder="address">
                        <input type="text" placeholder="Card no"><input type="text" placeholder="CVV">
                        <input type="date" placeholder="Experiy month"> 
                        <button class="conteud" type="submit">Order</button>

                    </form>
                </nav>
            </div>
        </aside>
    </div>
</div>




    </body>
    </html>