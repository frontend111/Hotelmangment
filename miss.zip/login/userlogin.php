
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" href="/HotelManagement/login/loginstyle.css">
</head>
<body>
 
	
	<div class="container">
	<h1>Login</h1>
	<form method="POST" action="/HotelManagement/login/login.php">
		<label for="username">Username:</label>
		<input type="text"  name="username" required><br><br>
		<label for="password">Password:</label>
		<input type="password" name="password" required><br><br>
		<input type="submit" value="Login">
	</form>
	<br>
	<hr>

    <a href="/HotelManagement/registration/registration.php">Register</a>
	</div>
	<script>
		
	</script>
</body>
</html>
